export class Contact{
    id:number;
    name: string;
    username: string;
    email: string;
    adress?:Object;
    phone?:String;
    website?: string;
    company?: string;
}