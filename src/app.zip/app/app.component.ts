import { Component } from '@angular/core';
import {Contact} from './models/contact';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  //déclaration d'une variable
  title = 'Gestion de contacts';
  contactActif :Contact;


  //déclaration d'un objet
  unContact = {
    id:1,
    name:'Tillai',
    username: 'Eshwar',
    email : 'eshwar@gmail.com'
  };

  mesContacts:any = [
    {
      id:1,
      name:'Shigaraki Tomura',
      username: 'Shigaraki',
      email : 'Shigaraki@gmail.com'

    },
    {
      id:2,
      name:'Uchiha Madara',
      username: 'Madara',
      email : 'Goat@gmail.com'

    },
    {
      id:3,
      name:'Sosuke Aizen',
      username: 'Aizen',
      email : 'Aizen@gmail.com'

    },
    {
      id:4,
      name:'Don Quichotte Doflamingo ',
      username: 'Doflamingo',
      email : 'Doffy@gmail.com'

    }

  ];

  displayProfil(contact:any){
    console.log(contact);
    this.contactActif= contact;
  }
}
